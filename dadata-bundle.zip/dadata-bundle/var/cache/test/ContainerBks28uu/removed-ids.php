<?php

namespace ContainerBks28uu;

return [
    'Psr\\Container\\ContainerInterface' => true,
    'Symfony\\Component\\DependencyInjection\\ContainerInterface' => true,
    'Velhron\\DadataBundle\\Service\\AbstractService' => true,
    'Velhron\\DadataBundle\\Service\\DadataClean' => true,
    'Velhron\\DadataBundle\\Service\\DadataGeneral' => true,
    'Velhron\\DadataBundle\\Service\\DadataGeolocate' => true,
    'Velhron\\DadataBundle\\Service\\DadataIplocate' => true,
    'Velhron\\DadataBundle\\Service\\DadataSuggest' => true,
];
