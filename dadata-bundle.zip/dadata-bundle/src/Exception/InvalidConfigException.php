<?php

declare(strict_types=1);

namespace Velhron\DadataBundle\Exception;

use Exception;

class InvalidConfigException extends Exception
{
}
