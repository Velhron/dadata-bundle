<?php

declare(strict_types=1);

namespace Velhron\DadataBundle\Model\Response\Geolocate;

use Velhron\DadataBundle\Model\Response\Suggest\SuggestResponse;

abstract class GeolocateResponse extends SuggestResponse
{
}
