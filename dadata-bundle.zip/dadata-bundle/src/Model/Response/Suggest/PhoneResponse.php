<?php

declare(strict_types=1);

namespace Velhron\DadataBundle\Model\Response\Suggest;

use Velhron\DadataBundle\Traits\Phone;

class PhoneResponse extends SuggestResponse
{
    use Phone;
}
