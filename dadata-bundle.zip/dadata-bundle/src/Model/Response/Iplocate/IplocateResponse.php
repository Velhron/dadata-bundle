<?php

declare(strict_types=1);

namespace Velhron\DadataBundle\Model\Response\Iplocate;

use Velhron\DadataBundle\Model\Response\Suggest\SuggestResponse;

abstract class IplocateResponse extends SuggestResponse
{
}
