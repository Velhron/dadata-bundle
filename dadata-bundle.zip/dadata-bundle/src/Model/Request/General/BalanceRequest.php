<?php

declare(strict_types=1);

namespace Velhron\DadataBundle\Model\Request\General;

class BalanceRequest extends GeneralRequest
{
}
