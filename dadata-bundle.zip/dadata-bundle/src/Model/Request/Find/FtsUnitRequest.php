<?php

declare(strict_types=1);

namespace Velhron\DadataBundle\Model\Request\Find;

class FtsUnitRequest extends FindRequest
{
}
