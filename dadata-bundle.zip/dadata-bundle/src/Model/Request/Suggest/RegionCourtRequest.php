<?php

declare(strict_types=1);

namespace Velhron\DadataBundle\Model\Request\Suggest;

class RegionCourtRequest extends SuggestRequest
{
    /**
     * @var array Фильтрация
     */
    protected $filters;
}
